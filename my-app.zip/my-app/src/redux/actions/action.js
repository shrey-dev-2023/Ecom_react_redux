export const ADD = (item) =>{
    return{
        type: "ADD_TO_CART",
        payload: item
    }
}

// remove items
export const DELETE = (uniqueid) =>{
    return{
        type: "RMV_TO_CART",
        payload: uniqueid
    }
}

// remove individual item
export const REMOVE = (item) =>{
    return{
        type: "RMV_ONE_QNTY",
        payload: item
    }
}