import React, { useState } from "react";
import { Link } from "react-router-dom";
import CardsData from "../components/CardsData";
import { useDispatch } from "react-redux";
import { ADD } from "../redux/actions/action";

const OurStore = () => {
  const [data, setData] = useState(CardsData);
  // console.log(data)

  const dispatch = useDispatch()


  const send = (e) => {
      // console.log(e)
      dispatch(ADD(e));
  }
  
  return (
    <>
      <section className="home-wrapper-2 py-3">
        <div className="container-xxl">
          <div className="row">
            <div className="col-12 d-flex align-items-center justify-content-between">
              {data.map((element, id) => {
                return (
                  <>
                    <div className="card" style={{ width: "18rem" }}>
                      <img
                        src={element.imgdata}
                        className="card-img-top"
                        alt="..."
                      />
                      <div className="card-body">
                        <h5 className="card-title">{element.pname}</h5>
                        <div className="card-text">
                          INR {element.price}
                         
                        </div>
                        <Link className="button" onClick={()=>send(element)}>ADD TO CART</Link>
                      </div>
                    </div>
                  </>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default OurStore;
