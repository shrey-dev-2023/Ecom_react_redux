const CardsData = [
    {
        uniqueid: 1,
        pname: "iPhone 13 Pro Max",
        imgdata: "images/tab.jpg",
        price: 109000,
        qnty: 0
    },
    {
        uniqueid: 2,
        pname: "MacBook Ultra M1 Chip",
        imgdata: "images/tab1.jpg",
        price: 108000,
        qnty: 0
    },
    {
        uniqueid: 3,
        pname: "iPad 12",
        imgdata: "images/tab2.jpg",
        price: 107000,
        qnty: 0
    },
    {
        uniqueid: 4,
        pname: "iWatch Ultra",
        imgdata: "images/tab3.jpg",
        price: 106000,
        qnty: 0
    }
]
export default CardsData;