import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { DELETE, ADD, REMOVE } from "../redux/actions/action";
import { useNavigate, useParams } from "react-router-dom";
import CardsData from "../components/CardsData";

const CardDetails = () => {
// const {id} = useParams()

  const[price, setPrice] = useState(0)
  // console.log(price)

  const getdata = useSelector((state) => state.cartreducer.carts);

  const total = () => {
    let price = 0;
    getdata.map((ele, k) => {
      price = ele.price * ele.qnty + price
    })
    setPrice(price)
  }
  useEffect(()=>{
    total();
  },[total])

  const dispatch = useDispatch()

  // const history = useNavigate()

  // add data
  const send = (e) => {
    dispatch(ADD(e));
  }

  const dlt = (uniqueid) => {
    dispatch(DELETE(uniqueid))
    // getdata.length != 0 ? history("/about") : history("/")
  }

  // remove one item
  const remove = (item) => {
dispatch(REMOVE(item))
  }

  return (
    <>
      <div className="container mt-2 mb-2">
        <h2 className="text-center">Items Details Page</h2>
        <section className="container mt-3">
          <div className="card">
            {getdata.map((e) => {
              return (
                <>
                  <div className="card-body d-flex justify-content-around align-items-center">
                    <span className="card-title">
                      <img src={e.imgdata} style={{ width: 200 }} alt="" />
                    </span>
                    <span>
                      <h5>{e.pname}</h5>
                      <p>
                        <strong>Price: </strong>
                        {e.price}
                      </p>
                      <p>
                        <strong>Total: </strong>
                        {e.price * e.qnty}
                      </p>
                      <p>
                        <strong>Quantity: </strong>
                        {e.qnty}
                        <button className="btn button1 mx-2" onClick={e.qnty<=1 ? ()=>dlt(e.uniqueid) : ()=>remove(e)}>-</button>
                        <button className="btn button1 mx-2" onClick={()=>send(e)}>+</button>
                      </p>
                      <div>
                        <button className="btn button-remove" onClick={()=>dlt(e.uniqueid)}>
                          Remove Item
                        </button>
                      </div>
                    </span>
                  </div>
                </>
              );
            })}
            <h5 className="d-flex justify-content-center align-item-center">Total: {price}</h5>
          </div>
        </section>
      </div>
    </>
  );
};

export default CardDetails;
